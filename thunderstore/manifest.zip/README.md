# UKFreshnessCoach

Makes it more apparent when weapon freshness has run out by adding a gentle reminder below the
crosshair.

![UKFreshnessCoach demo](https://github.com/prophetofxenu/UKFreshnessCoach/assets/20529712/5bd6bb58-220e-41e5-8093-012cebac0ce9)

Messages can be customized in the configuration.

## Manual Install

After installing BepInEx, copy UKFreshnessCoach.dll to your BepInEx/plugins.

## Configuration

You can customize the messages shown in BepInEx/config/UKFreshnessCoach.cfg (after running the
game with the mod installed to generate the config.)
